#define SYS_LSA_VERSION         "V04.00.00.00"
#define SYS_LSA_DATE            "2009/12/17"
/* Version number as incrementing integer: */
#define SYS_LSA_VERSION_CNT     82
/* Version number as integer build from version: */
#define SYS_LSA_VERSION_NUM     4000000

