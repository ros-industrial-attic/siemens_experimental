/* SIMATIC NET-spezifische Definitionen */

#define SIN_COMPANY_NAME    "Siemens AG\0"
#define SIN_LEGALCOPYRIGHT  "Copyright (C) SIEMENS CORP., 2013 All rights reserved.
#define SIN_LEGALTRADEMARKS "Siemens AG\0"
#define SIN_PRODUCT_STR     "SIMATIC NET PC Software\0"
