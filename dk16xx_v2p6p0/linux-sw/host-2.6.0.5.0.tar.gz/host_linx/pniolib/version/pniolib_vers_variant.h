/*******************************************************************************
 *
 *   Name         : pniolib_vers_variant.h     PNIOLib Version Header File
 *
 *   Description  : Version File. Defines PNIOLib Version Number
 *
 *   History      : All changes have to be documented below
 *   ========
 *
 ******************************************************************************/

// 26-06-2007: PNIOLib version number created
//             1st Linwin version
//
#define MY_PNIOLIB_VER_VARIANT     3



