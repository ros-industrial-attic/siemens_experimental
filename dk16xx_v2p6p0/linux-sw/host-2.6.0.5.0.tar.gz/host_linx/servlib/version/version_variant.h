/*******************************************************************************
 *
 *   Name         : version_variant.h
 *
 *   Description  : Version File. Defines servlib Version Number
 *
 *   History      : All changes have to be documented below
 *   ========
 *
 ******************************************************************************/

// 29-08-2007: servlib version number created
//             1st Linwin version
//
#define MY_PNIOLIB_VER_VARIANT     3



