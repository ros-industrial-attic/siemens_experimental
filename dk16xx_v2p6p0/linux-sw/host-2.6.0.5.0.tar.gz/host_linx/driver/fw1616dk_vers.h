#define VERTXT   "Fw16xx" 
#define VERPRFX  "V" 
#define VERSUFX  "" 
#define FW_DATE  __DATE__
#define FW_VER_MAJOR 2
#define FW_VER_MINOR1 6
#define FW_VER_MINOR2 0
#define FW_VER_MINOR3 5
#define FW_VER_MINOR4 0

#define VERSION_BUILD_NUMBER FW_VER_MINOR3
